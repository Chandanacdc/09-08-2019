import { DeliverService } from '../deliverylist/deliverlist.service';
import { HttpClient } from '@angular/common/http';
import { DeliverList} from '../deliverylist/deliverlist.interface';
import { FormBuilder,FormGroup,FormArray} from '@angular/forms';
import { User } from './adddelivery';
import { Component, OnInit } from '@angular/core';

@Component({
templateUrl:'./adddelivery.component.html',
})



export class AddDeliveryComponent implements OnInit{
    DeliverlistService: any;
    user = new User();
  registerForm:FormGroup; 
deliverlist:DeliverList[]=[];
  
  constructor(private fb:FormBuilder, private deliverservice:DeliverService){

  }
  
  ngOnInit():void{
    this.registerForm=this.fb.group({
      courierId :'',
       name :'',
      age:'',
     price:'',
      weight:''
    })
  
    }
   
    

    save(){
        console.log(this.registerForm);
        console.log('saved data'+ JSON.stringify(this.registerForm.value));
      }
    
    createUser():void{
    this.DeliverlistService.createUser(this.deliverlist).subscribe(data =>{
        alert("user data inserted successfully");
    });
}
}