export class User{
constructor(
public courierId ='',
public name ='',
public age ='',
public price='',
  public weight='')

{}

}
   